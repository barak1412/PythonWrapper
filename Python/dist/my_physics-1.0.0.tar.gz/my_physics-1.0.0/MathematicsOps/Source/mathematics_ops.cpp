#include "mathematics_ops.h"


float sum_op(float a, float b)
{
	return a + b;
}

float mul_op(float a, float b)
{
	return a * b;
}