
float sum_op(float a, float b);
float mul_op(float a, float b);