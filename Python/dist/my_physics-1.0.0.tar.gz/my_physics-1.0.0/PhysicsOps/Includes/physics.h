
float gforce(float weight);
float velocity(float v0, float a, float t);